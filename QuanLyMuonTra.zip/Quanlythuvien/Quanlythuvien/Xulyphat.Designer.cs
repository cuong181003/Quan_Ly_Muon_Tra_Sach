﻿namespace Quanlythuvien
{
    partial class Xulyphat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Xulyphat));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.txtTheDG = new System.Windows.Forms.TextBox();
            this.groupBox_functions = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_xoa = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_sua = new System.Windows.Forms.Button();
            this.btn_them = new System.Windows.Forms.Button();
            this.txt_hinhthuc = new System.Windows.Forms.TextBox();
            this.lbl_hinhthuc = new System.Windows.Forms.Label();
            this.dtp_ngayPhat = new System.Windows.Forms.DateTimePicker();
            this.lbl_ngayPhat = new System.Windows.Forms.Label();
            this.txt_lyDo = new System.Windows.Forms.TextBox();
            this.lbl_lyDo = new System.Windows.Forms.Label();
            this.txt_tienPhat = new System.Windows.Forms.TextBox();
            this.lbl_tienPhat = new System.Windows.Forms.Label();
            this.lbl_maNV = new System.Windows.Forms.Label();
            this.lbl_tenDG = new System.Windows.Forms.Label();
            this.txt_soHoaDon = new System.Windows.Forms.TextBox();
            this.lbl_soHoaDon = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox_functions.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-1, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1282, 131);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OliveDrab;
            this.label1.Location = new System.Drawing.Point(691, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bills";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(503, -13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(223, 153);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 166);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1257, 385);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.SeaShell;
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.txtMaNV);
            this.panel2.Controls.Add(this.txtTheDG);
            this.panel2.Controls.Add(this.groupBox_functions);
            this.panel2.Controls.Add(this.txt_hinhthuc);
            this.panel2.Controls.Add(this.lbl_hinhthuc);
            this.panel2.Controls.Add(this.dtp_ngayPhat);
            this.panel2.Controls.Add(this.lbl_ngayPhat);
            this.panel2.Controls.Add(this.txt_lyDo);
            this.panel2.Controls.Add(this.lbl_lyDo);
            this.panel2.Controls.Add(this.txt_tienPhat);
            this.panel2.Controls.Add(this.lbl_tienPhat);
            this.panel2.Controls.Add(this.lbl_maNV);
            this.panel2.Controls.Add(this.lbl_tenDG);
            this.panel2.Controls.Add(this.txt_soHoaDon);
            this.panel2.Controls.Add(this.lbl_soHoaDon);
            this.panel2.Location = new System.Drawing.Point(12, 577);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1237, 249);
            this.panel2.TabIndex = 6;
            // 
            // txtMaNV
            // 
            this.txtMaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaNV.Location = new System.Drawing.Point(185, 151);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(162, 27);
            this.txtMaNV.TabIndex = 56;
            // 
            // txtTheDG
            // 
            this.txtTheDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTheDG.Location = new System.Drawing.Point(185, 85);
            this.txtTheDG.Name = "txtTheDG";
            this.txtTheDG.Size = new System.Drawing.Size(162, 27);
            this.txtTheDG.TabIndex = 55;
            // 
            // groupBox_functions
            // 
            this.groupBox_functions.BackColor = System.Drawing.Color.SeaShell;
            this.groupBox_functions.Controls.Add(this.button1);
            this.groupBox_functions.Controls.Add(this.btn_xoa);
            this.groupBox_functions.Controls.Add(this.button2);
            this.groupBox_functions.Controls.Add(this.btn_sua);
            this.groupBox_functions.Controls.Add(this.btn_them);
            this.groupBox_functions.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_functions.Location = new System.Drawing.Point(950, 136);
            this.groupBox_functions.Name = "groupBox_functions";
            this.groupBox_functions.Size = new System.Drawing.Size(290, 110);
            this.groupBox_functions.TabIndex = 54;
            this.groupBox_functions.TabStop = false;
            this.groupBox_functions.Text = "Chức năng";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MintCream;
            this.button1.Location = new System.Drawing.Point(6, 70);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 38);
            this.button1.TabIndex = 44;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_xoa
            // 
            this.btn_xoa.BackColor = System.Drawing.Color.Firebrick;
            this.btn_xoa.Location = new System.Drawing.Point(203, 27);
            this.btn_xoa.Name = "btn_xoa";
            this.btn_xoa.Size = new System.Drawing.Size(81, 35);
            this.btn_xoa.TabIndex = 4;
            this.btn_xoa.Text = "Xóa";
            this.btn_xoa.UseVisualStyleBackColor = false;
            this.btn_xoa.Click += new System.EventHandler(this.btn_xoa_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MintCream;
            this.button2.Location = new System.Drawing.Point(107, 69);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(177, 38);
            this.button2.TabIndex = 43;
            this.button2.Text = "Tìm kiếm";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_sua
            // 
            this.btn_sua.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_sua.Location = new System.Drawing.Point(107, 27);
            this.btn_sua.Name = "btn_sua";
            this.btn_sua.Size = new System.Drawing.Size(81, 35);
            this.btn_sua.TabIndex = 3;
            this.btn_sua.Text = "Sửa";
            this.btn_sua.UseVisualStyleBackColor = false;
            this.btn_sua.Click += new System.EventHandler(this.btn_sua_Click);
            // 
            // btn_them
            // 
            this.btn_them.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_them.Location = new System.Drawing.Point(6, 26);
            this.btn_them.Name = "btn_them";
            this.btn_them.Size = new System.Drawing.Size(81, 35);
            this.btn_them.TabIndex = 1;
            this.btn_them.Text = "Thêm";
            this.btn_them.UseVisualStyleBackColor = false;
            this.btn_them.Click += new System.EventHandler(this.btn_them_Click);
            // 
            // txt_hinhthuc
            // 
            this.txt_hinhthuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_hinhthuc.Location = new System.Drawing.Point(684, 219);
            this.txt_hinhthuc.Name = "txt_hinhthuc";
            this.txt_hinhthuc.Size = new System.Drawing.Size(167, 27);
            this.txt_hinhthuc.TabIndex = 33;
            // 
            // lbl_hinhthuc
            // 
            this.lbl_hinhthuc.AutoSize = true;
            this.lbl_hinhthuc.BackColor = System.Drawing.Color.White;
            this.lbl_hinhthuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hinhthuc.Location = new System.Drawing.Point(555, 219);
            this.lbl_hinhthuc.Name = "lbl_hinhthuc";
            this.lbl_hinhthuc.Size = new System.Drawing.Size(81, 20);
            this.lbl_hinhthuc.TabIndex = 32;
            this.lbl_hinhthuc.Text = "Hình thức";
            // 
            // dtp_ngayPhat
            // 
            this.dtp_ngayPhat.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_ngayPhat.CustomFormat = "";
            this.dtp_ngayPhat.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_ngayPhat.Location = new System.Drawing.Point(688, 162);
            this.dtp_ngayPhat.Name = "dtp_ngayPhat";
            this.dtp_ngayPhat.Size = new System.Drawing.Size(150, 22);
            this.dtp_ngayPhat.TabIndex = 28;
            // 
            // lbl_ngayPhat
            // 
            this.lbl_ngayPhat.AutoSize = true;
            this.lbl_ngayPhat.BackColor = System.Drawing.Color.White;
            this.lbl_ngayPhat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ngayPhat.Location = new System.Drawing.Point(555, 162);
            this.lbl_ngayPhat.Name = "lbl_ngayPhat";
            this.lbl_ngayPhat.Size = new System.Drawing.Size(84, 20);
            this.lbl_ngayPhat.TabIndex = 22;
            this.lbl_ngayPhat.Text = "Ngày phạt";
            // 
            // txt_lyDo
            // 
            this.txt_lyDo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lyDo.Location = new System.Drawing.Point(684, 112);
            this.txt_lyDo.Name = "txt_lyDo";
            this.txt_lyDo.Size = new System.Drawing.Size(214, 27);
            this.txt_lyDo.TabIndex = 21;
            // 
            // lbl_lyDo
            // 
            this.lbl_lyDo.AutoSize = true;
            this.lbl_lyDo.BackColor = System.Drawing.Color.White;
            this.lbl_lyDo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lyDo.Location = new System.Drawing.Point(555, 115);
            this.lbl_lyDo.Name = "lbl_lyDo";
            this.lbl_lyDo.Size = new System.Drawing.Size(55, 20);
            this.lbl_lyDo.TabIndex = 20;
            this.lbl_lyDo.Text = "Lý do ";
            // 
            // txt_tienPhat
            // 
            this.txt_tienPhat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tienPhat.Location = new System.Drawing.Point(684, 21);
            this.txt_tienPhat.Name = "txt_tienPhat";
            this.txt_tienPhat.Size = new System.Drawing.Size(167, 27);
            this.txt_tienPhat.TabIndex = 19;
            // 
            // lbl_tienPhat
            // 
            this.lbl_tienPhat.AutoSize = true;
            this.lbl_tienPhat.BackColor = System.Drawing.Color.White;
            this.lbl_tienPhat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tienPhat.Location = new System.Drawing.Point(537, 24);
            this.lbl_tienPhat.Name = "lbl_tienPhat";
            this.lbl_tienPhat.Size = new System.Drawing.Size(82, 20);
            this.lbl_tienPhat.TabIndex = 18;
            this.lbl_tienPhat.Text = "Tiền sách";
            // 
            // lbl_maNV
            // 
            this.lbl_maNV.AutoSize = true;
            this.lbl_maNV.BackColor = System.Drawing.Color.White;
            this.lbl_maNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_maNV.Location = new System.Drawing.Point(13, 151);
            this.lbl_maNV.Name = "lbl_maNV";
            this.lbl_maNV.Size = new System.Drawing.Size(108, 20);
            this.lbl_maNV.TabIndex = 5;
            this.lbl_maNV.Text = "Mã nhân viên";
            // 
            // lbl_tenDG
            // 
            this.lbl_tenDG.AutoSize = true;
            this.lbl_tenDG.BackColor = System.Drawing.Color.White;
            this.lbl_tenDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tenDG.Location = new System.Drawing.Point(13, 88);
            this.lbl_tenDG.Name = "lbl_tenDG";
            this.lbl_tenDG.Size = new System.Drawing.Size(116, 20);
            this.lbl_tenDG.TabIndex = 3;
            this.lbl_tenDG.Text = "Số thẻ độc giả";
            // 
            // txt_soHoaDon
            // 
            this.txt_soHoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_soHoaDon.Location = new System.Drawing.Point(185, 21);
            this.txt_soHoaDon.Name = "txt_soHoaDon";
            this.txt_soHoaDon.Size = new System.Drawing.Size(162, 27);
            this.txt_soHoaDon.TabIndex = 2;
            // 
            // lbl_soHoaDon
            // 
            this.lbl_soHoaDon.AutoSize = true;
            this.lbl_soHoaDon.BackColor = System.Drawing.Color.White;
            this.lbl_soHoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_soHoaDon.Location = new System.Drawing.Point(13, 24);
            this.lbl_soHoaDon.Name = "lbl_soHoaDon";
            this.lbl_soHoaDon.Size = new System.Drawing.Size(98, 20);
            this.lbl_soHoaDon.TabIndex = 1;
            this.lbl_soHoaDon.Text = "Số hóa đơn ";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "10%",
            "20%",
            "30%",
            "40%",
            "50%",
            "60%",
            "70%",
            "80%",
            "90%",
            "100%"});
            this.comboBox1.Location = new System.Drawing.Point(185, 210);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(162, 24);
            this.comboBox1.TabIndex = 57;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 20);
            this.label2.TabIndex = 58;
            this.label2.Text = "Tình trạng hư hại";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(684, 65);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(167, 27);
            this.textBox1.TabIndex = 60;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(537, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 20);
            this.label3.TabIndex = 59;
            this.label3.Text = "Tiền phạt ";
            // 
            // Xulyphat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1301, 731);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Xulyphat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Xử lý phạt";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox_functions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_hinhthuc;
        private System.Windows.Forms.Label lbl_hinhthuc;
        private System.Windows.Forms.DateTimePicker dtp_ngayPhat;
        private System.Windows.Forms.Label lbl_ngayPhat;
        private System.Windows.Forms.TextBox txt_lyDo;
        private System.Windows.Forms.Label lbl_lyDo;
        private System.Windows.Forms.TextBox txt_tienPhat;
        private System.Windows.Forms.Label lbl_tienPhat;
        private System.Windows.Forms.Label lbl_maNV;
        private System.Windows.Forms.Label lbl_tenDG;
        private System.Windows.Forms.TextBox txt_soHoaDon;
        private System.Windows.Forms.Label lbl_soHoaDon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox_functions;
        private System.Windows.Forms.Button btn_xoa;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_sua;
        private System.Windows.Forms.Button btn_them;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.TextBox txtTheDG;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
    }
}