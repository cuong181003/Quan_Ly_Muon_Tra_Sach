﻿namespace Quanlythuvien
{
    partial class The
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(The));
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_handung_The = new System.Windows.Forms.TextBox();
            this.txt_ngaycap_The = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl_handung_The = new System.Windows.Forms.Label();
            this.lbl_ngaycap_The = new System.Windows.Forms.Label();
            this.txt_maDG_The = new System.Windows.Forms.TextBox();
            this.lbl_maDG_The = new System.Windows.Forms.Label();
            this.txt_sotheDG_The = new System.Windows.Forms.TextBox();
            this.lbl_sotheDG_The = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.printDocument_The = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog_The = new System.Windows.Forms.PrintPreviewDialog();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.Controls.Add(this.txt_handung_The);
            this.panel2.Controls.Add(this.txt_ngaycap_The);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.lbl_handung_The);
            this.panel2.Controls.Add(this.lbl_ngaycap_The);
            this.panel2.Controls.Add(this.txt_maDG_The);
            this.panel2.Controls.Add(this.lbl_maDG_The);
            this.panel2.Controls.Add(this.txt_sotheDG_The);
            this.panel2.Controls.Add(this.lbl_sotheDG_The);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(541, 262);
            this.panel2.TabIndex = 6;
            // 
            // txt_handung_The
            // 
            this.txt_handung_The.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_handung_The.Location = new System.Drawing.Point(305, 202);
            this.txt_handung_The.Name = "txt_handung_The";
            this.txt_handung_The.ReadOnly = true;
            this.txt_handung_The.Size = new System.Drawing.Size(178, 27);
            this.txt_handung_The.TabIndex = 30;
            // 
            // txt_ngaycap_The
            // 
            this.txt_ngaycap_The.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ngaycap_The.Location = new System.Drawing.Point(305, 162);
            this.txt_ngaycap_The.Name = "txt_ngaycap_The";
            this.txt_ngaycap_The.ReadOnly = true;
            this.txt_ngaycap_The.Size = new System.Drawing.Size(178, 27);
            this.txt_ngaycap_The.TabIndex = 29;
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Location = new System.Drawing.Point(13, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(66, 59);
            this.panel3.TabIndex = 28;
            // 
            // lbl_handung_The
            // 
            this.lbl_handung_The.AutoSize = true;
            this.lbl_handung_The.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_handung_The.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_handung_The.Location = new System.Drawing.Point(176, 205);
            this.lbl_handung_The.Name = "lbl_handung_The";
            this.lbl_handung_The.Size = new System.Drawing.Size(86, 20);
            this.lbl_handung_The.TabIndex = 26;
            this.lbl_handung_The.Text = "Hạn dùng ";
            // 
            // lbl_ngaycap_The
            // 
            this.lbl_ngaycap_The.AutoSize = true;
            this.lbl_ngaycap_The.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_ngaycap_The.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ngaycap_The.Location = new System.Drawing.Point(176, 165);
            this.lbl_ngaycap_The.Name = "lbl_ngaycap_The";
            this.lbl_ngaycap_The.Size = new System.Drawing.Size(84, 20);
            this.lbl_ngaycap_The.TabIndex = 24;
            this.lbl_ngaycap_The.Text = "Ngày cấp ";
            // 
            // txt_maDG_The
            // 
            this.txt_maDG_The.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maDG_The.Location = new System.Drawing.Point(305, 119);
            this.txt_maDG_The.Name = "txt_maDG_The";
            this.txt_maDG_The.ReadOnly = true;
            this.txt_maDG_The.Size = new System.Drawing.Size(178, 27);
            this.txt_maDG_The.TabIndex = 23;
            // 
            // lbl_maDG_The
            // 
            this.lbl_maDG_The.AutoSize = true;
            this.lbl_maDG_The.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_maDG_The.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_maDG_The.Location = new System.Drawing.Point(176, 122);
            this.lbl_maDG_The.Name = "lbl_maDG_The";
            this.lbl_maDG_The.Size = new System.Drawing.Size(91, 20);
            this.lbl_maDG_The.TabIndex = 22;
            this.lbl_maDG_The.Text = "Mã độc giả";
            // 
            // txt_sotheDG_The
            // 
            this.txt_sotheDG_The.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sotheDG_The.Location = new System.Drawing.Point(305, 75);
            this.txt_sotheDG_The.Name = "txt_sotheDG_The";
            this.txt_sotheDG_The.ReadOnly = true;
            this.txt_sotheDG_The.Size = new System.Drawing.Size(178, 27);
            this.txt_sotheDG_The.TabIndex = 21;
            // 
            // lbl_sotheDG_The
            // 
            this.lbl_sotheDG_The.AutoSize = true;
            this.lbl_sotheDG_The.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_sotheDG_The.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sotheDG_The.Location = new System.Drawing.Point(176, 78);
            this.lbl_sotheDG_The.Name = "lbl_sotheDG_The";
            this.lbl_sotheDG_The.Size = new System.Drawing.Size(116, 20);
            this.lbl_sotheDG_The.TabIndex = 20;
            this.lbl_sotheDG_The.Text = "Số thẻ độc giả";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(13, 86);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(130, 134);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(107, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(332, 31);
            this.label3.TabIndex = 0;
            this.label3.Text = "Kinh tế kỹ thuật công nghiệp ";
            // 
            // printPreviewDialog_The
            // 
            this.printPreviewDialog_The.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_The.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog_The.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog_The.Enabled = true;
            this.printPreviewDialog_The.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog_The.Icon")));
            this.printPreviewDialog_The.Name = "printPreviewDialog_The";
            this.printPreviewDialog_The.Visible = false;
            // 
            // The
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 262);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "The";
            this.Text = "Thẻ";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_handung_The;
        private System.Windows.Forms.TextBox txt_ngaycap_The;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl_handung_The;
        private System.Windows.Forms.Label lbl_ngaycap_The;
        private System.Windows.Forms.TextBox txt_maDG_The;
        private System.Windows.Forms.Label lbl_maDG_The;
        private System.Windows.Forms.TextBox txt_sotheDG_The;
        private System.Windows.Forms.Label lbl_sotheDG_The;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Drawing.Printing.PrintDocument printDocument_The;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog_The;
    }
}