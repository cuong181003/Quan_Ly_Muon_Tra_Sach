﻿namespace Quanlythuvien
{
    partial class Capthedocgia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Capthedocgia));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtMaDg = new System.Windows.Forms.TextBox();
            this.groupBox_functions = new System.Windows.Forms.GroupBox();
            this.btngiahan = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_xoa = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_sua = new System.Windows.Forms.Button();
            this.btn_them = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_soTheDG_in = new System.Windows.Forms.Label();
            this.btn_inThe = new System.Windows.Forms.Button();
            this.dtp_handung = new System.Windows.Forms.DateTimePicker();
            this.lbl_handung = new System.Windows.Forms.Label();
            this.dtp_ngaycap = new System.Windows.Forms.DateTimePicker();
            this.lbl_ngaycap = new System.Windows.Forms.Label();
            this.lbl_maDG = new System.Windows.Forms.Label();
            this.txt_sotheDG = new System.Windows.Forms.TextBox();
            this.lbl_sotheDG = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox_functions.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(393, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(269, 156);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1063, 159);
            this.panel1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Green;
            this.label3.Location = new System.Drawing.Point(339, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 32);
            this.label3.TabIndex = 3;
            this.label3.Text = "der";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Green;
            this.label2.Location = new System.Drawing.Point(657, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "Cards";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(328, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Rea";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.SeaShell;
            this.panel2.Controls.Add(this.txtMaDg);
            this.panel2.Controls.Add(this.groupBox_functions);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.dtp_handung);
            this.panel2.Controls.Add(this.lbl_handung);
            this.panel2.Controls.Add(this.dtp_ngaycap);
            this.panel2.Controls.Add(this.lbl_ngaycap);
            this.panel2.Controls.Add(this.lbl_maDG);
            this.panel2.Controls.Add(this.txt_sotheDG);
            this.panel2.Controls.Add(this.lbl_sotheDG);
            this.panel2.Location = new System.Drawing.Point(8, 527);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1028, 280);
            this.panel2.TabIndex = 4;
            // 
            // txtMaDg
            // 
            this.txtMaDg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaDg.Location = new System.Drawing.Point(159, 65);
            this.txtMaDg.Name = "txtMaDg";
            this.txtMaDg.Size = new System.Drawing.Size(167, 27);
            this.txtMaDg.TabIndex = 54;
            // 
            // groupBox_functions
            // 
            this.groupBox_functions.BackColor = System.Drawing.Color.SeaShell;
            this.groupBox_functions.Controls.Add(this.btngiahan);
            this.groupBox_functions.Controls.Add(this.button1);
            this.groupBox_functions.Controls.Add(this.btn_xoa);
            this.groupBox_functions.Controls.Add(this.button2);
            this.groupBox_functions.Controls.Add(this.btn_sua);
            this.groupBox_functions.Controls.Add(this.btn_them);
            this.groupBox_functions.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_functions.Location = new System.Drawing.Point(17, 152);
            this.groupBox_functions.Name = "groupBox_functions";
            this.groupBox_functions.Size = new System.Drawing.Size(509, 110);
            this.groupBox_functions.TabIndex = 53;
            this.groupBox_functions.TabStop = false;
            this.groupBox_functions.Text = "Chức năng";
            // 
            // btngiahan
            // 
            this.btngiahan.BackColor = System.Drawing.Color.Firebrick;
            this.btngiahan.Location = new System.Drawing.Point(369, 26);
            this.btngiahan.Name = "btngiahan";
            this.btngiahan.Size = new System.Drawing.Size(124, 35);
            this.btngiahan.TabIndex = 45;
            this.btngiahan.Text = "Gia hạn";
            this.btngiahan.UseVisualStyleBackColor = false;
            this.btngiahan.Click += new System.EventHandler(this.btngiahan_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MintCream;
            this.button1.Location = new System.Drawing.Point(212, 70);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 38);
            this.button1.TabIndex = 44;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_xoa
            // 
            this.btn_xoa.BackColor = System.Drawing.Color.Firebrick;
            this.btn_xoa.Location = new System.Drawing.Point(257, 29);
            this.btn_xoa.Name = "btn_xoa";
            this.btn_xoa.Size = new System.Drawing.Size(81, 35);
            this.btn_xoa.TabIndex = 4;
            this.btn_xoa.Text = "Xóa";
            this.btn_xoa.UseVisualStyleBackColor = false;
            this.btn_xoa.Click += new System.EventHandler(this.btn_xoa_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MintCream;
            this.button2.Location = new System.Drawing.Point(11, 69);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(177, 38);
            this.button2.TabIndex = 43;
            this.button2.Text = "Tìm kiếm";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_sua
            // 
            this.btn_sua.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_sua.Location = new System.Drawing.Point(127, 26);
            this.btn_sua.Name = "btn_sua";
            this.btn_sua.Size = new System.Drawing.Size(81, 35);
            this.btn_sua.TabIndex = 3;
            this.btn_sua.Text = "Sửa";
            this.btn_sua.UseVisualStyleBackColor = false;
            this.btn_sua.Click += new System.EventHandler(this.btn_sua_Click);
            // 
            // btn_them
            // 
            this.btn_them.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_them.Location = new System.Drawing.Point(6, 26);
            this.btn_them.Name = "btn_them";
            this.btn_them.Size = new System.Drawing.Size(81, 35);
            this.btn_them.TabIndex = 1;
            this.btn_them.Text = "Thêm";
            this.btn_them.UseVisualStyleBackColor = false;
            this.btn_them.Click += new System.EventHandler(this.btn_them_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_soTheDG_in);
            this.groupBox1.Controls.Add(this.btn_inThe);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(671, 148);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(347, 108);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            // 
            // lbl_soTheDG_in
            // 
            this.lbl_soTheDG_in.AutoSize = true;
            this.lbl_soTheDG_in.BackColor = System.Drawing.Color.White;
            this.lbl_soTheDG_in.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_soTheDG_in.Location = new System.Drawing.Point(46, 60);
            this.lbl_soTheDG_in.Name = "lbl_soTheDG_in";
            this.lbl_soTheDG_in.Size = new System.Drawing.Size(116, 20);
            this.lbl_soTheDG_in.TabIndex = 21;
            this.lbl_soTheDG_in.Text = "Số thẻ độc giả";
            // 
            // btn_inThe
            // 
            this.btn_inThe.BackColor = System.Drawing.Color.LightBlue;
            this.btn_inThe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_inThe.Location = new System.Drawing.Point(194, 60);
            this.btn_inThe.Name = "btn_inThe";
            this.btn_inThe.Size = new System.Drawing.Size(109, 35);
            this.btn_inThe.TabIndex = 23;
            this.btn_inThe.Text = "In thẻ";
            this.btn_inThe.UseVisualStyleBackColor = false;
            this.btn_inThe.Click += new System.EventHandler(this.btn_inThe_Click);
            // 
            // dtp_handung
            // 
            this.dtp_handung.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_handung.CustomFormat = "";
            this.dtp_handung.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_handung.Location = new System.Drawing.Point(824, 61);
            this.dtp_handung.Name = "dtp_handung";
            this.dtp_handung.Size = new System.Drawing.Size(150, 22);
            this.dtp_handung.TabIndex = 19;
            // 
            // lbl_handung
            // 
            this.lbl_handung.AutoSize = true;
            this.lbl_handung.BackColor = System.Drawing.Color.White;
            this.lbl_handung.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_handung.Location = new System.Drawing.Point(696, 61);
            this.lbl_handung.Name = "lbl_handung";
            this.lbl_handung.Size = new System.Drawing.Size(86, 20);
            this.lbl_handung.TabIndex = 18;
            this.lbl_handung.Text = "Hạn dùng ";
            // 
            // dtp_ngaycap
            // 
            this.dtp_ngaycap.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_ngaycap.CustomFormat = "";
            this.dtp_ngaycap.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_ngaycap.Location = new System.Drawing.Point(824, 18);
            this.dtp_ngaycap.Name = "dtp_ngaycap";
            this.dtp_ngaycap.Size = new System.Drawing.Size(150, 22);
            this.dtp_ngaycap.TabIndex = 12;
            // 
            // lbl_ngaycap
            // 
            this.lbl_ngaycap.AutoSize = true;
            this.lbl_ngaycap.BackColor = System.Drawing.Color.White;
            this.lbl_ngaycap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ngaycap.Location = new System.Drawing.Point(696, 20);
            this.lbl_ngaycap.Name = "lbl_ngaycap";
            this.lbl_ngaycap.Size = new System.Drawing.Size(84, 20);
            this.lbl_ngaycap.TabIndex = 11;
            this.lbl_ngaycap.Text = "Ngày cấp ";
            // 
            // lbl_maDG
            // 
            this.lbl_maDG.AutoSize = true;
            this.lbl_maDG.BackColor = System.Drawing.Color.White;
            this.lbl_maDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_maDG.Location = new System.Drawing.Point(13, 65);
            this.lbl_maDG.Name = "lbl_maDG";
            this.lbl_maDG.Size = new System.Drawing.Size(91, 20);
            this.lbl_maDG.TabIndex = 3;
            this.lbl_maDG.Text = "Mã độc giả";
            // 
            // txt_sotheDG
            // 
            this.txt_sotheDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sotheDG.Location = new System.Drawing.Point(159, 17);
            this.txt_sotheDG.Name = "txt_sotheDG";
            this.txt_sotheDG.Size = new System.Drawing.Size(167, 27);
            this.txt_sotheDG.TabIndex = 2;
            // 
            // lbl_sotheDG
            // 
            this.lbl_sotheDG.AutoSize = true;
            this.lbl_sotheDG.BackColor = System.Drawing.Color.White;
            this.lbl_sotheDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sotheDG.Location = new System.Drawing.Point(13, 17);
            this.lbl_sotheDG.Name = "lbl_sotheDG";
            this.lbl_sotheDG.Size = new System.Drawing.Size(116, 20);
            this.lbl_sotheDG.TabIndex = 1;
            this.lbl_sotheDG.Text = "Số thẻ độc giả";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 179);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1044, 290);
            this.dataGridView1.TabIndex = 9;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // Capthedocgia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1064, 668);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Capthedocgia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cấp thẻ độc giả";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox_functions.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_soTheDG_in;
        private System.Windows.Forms.Button btn_inThe;
        private System.Windows.Forms.DateTimePicker dtp_handung;
        private System.Windows.Forms.Label lbl_handung;
        private System.Windows.Forms.DateTimePicker dtp_ngaycap;
        private System.Windows.Forms.Label lbl_ngaycap;
        private System.Windows.Forms.Label lbl_maDG;
        private System.Windows.Forms.TextBox txt_sotheDG;
        private System.Windows.Forms.Label lbl_sotheDG;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox_functions;
        private System.Windows.Forms.Button btn_xoa;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_sua;
        private System.Windows.Forms.Button btn_them;
        private System.Windows.Forms.TextBox txtMaDg;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btngiahan;
    }
}