﻿namespace Quanlythuvien
{
    partial class Quanlysach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Quanlysach));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.txt_tacGia = new System.Windows.Forms.TextBox();
            this.txt_nxb = new System.Windows.Forms.TextBox();
            this.txt_tenSach = new System.Windows.Forms.TextBox();
            this.txt_maSach = new System.Windows.Forms.TextBox();
            this.lbl_tacGia = new System.Windows.Forms.Label();
            this.lbl_nxb = new System.Windows.Forms.Label();
            this.lbl_tenSach = new System.Windows.Forms.Label();
            this.lbl_maSach = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1298, 127);
            this.panel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MediumAquamarine;
            this.label3.Location = new System.Drawing.Point(739, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Books";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(514, -31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(296, 187);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(346, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 46);
            this.button1.TabIndex = 3;
            this.button1.Text = "Tìm Kiếm";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 189);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1277, 391);
            this.dataGridView1.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SeaShell;
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.txt_tacGia);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.txt_nxb);
            this.panel2.Controls.Add(this.txt_tenSach);
            this.panel2.Controls.Add(this.txt_maSach);
            this.panel2.Controls.Add(this.lbl_tacGia);
            this.panel2.Controls.Add(this.lbl_nxb);
            this.panel2.Controls.Add(this.lbl_tenSach);
            this.panel2.Controls.Add(this.lbl_maSach);
            this.panel2.Location = new System.Drawing.Point(12, 621);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1276, 228);
            this.panel2.TabIndex = 5;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MintCream;
            this.button2.Location = new System.Drawing.Point(612, 137);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(165, 46);
            this.button2.TabIndex = 41;
            this.button2.Text = "Refresh";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txt_tacGia
            // 
            this.txt_tacGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tacGia.Location = new System.Drawing.Point(750, 73);
            this.txt_tacGia.Name = "txt_tacGia";
            this.txt_tacGia.Size = new System.Drawing.Size(253, 27);
            this.txt_tacGia.TabIndex = 31;
            // 
            // txt_nxb
            // 
            this.txt_nxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nxb.Location = new System.Drawing.Point(750, 25);
            this.txt_nxb.Name = "txt_nxb";
            this.txt_nxb.Size = new System.Drawing.Size(253, 27);
            this.txt_nxb.TabIndex = 30;
            // 
            // txt_tenSach
            // 
            this.txt_tenSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tenSach.Location = new System.Drawing.Point(169, 73);
            this.txt_tenSach.Name = "txt_tenSach";
            this.txt_tenSach.Size = new System.Drawing.Size(253, 27);
            this.txt_tenSach.TabIndex = 29;
            // 
            // txt_maSach
            // 
            this.txt_maSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maSach.Location = new System.Drawing.Point(169, 25);
            this.txt_maSach.Name = "txt_maSach";
            this.txt_maSach.Size = new System.Drawing.Size(253, 27);
            this.txt_maSach.TabIndex = 28;
            // 
            // lbl_tacGia
            // 
            this.lbl_tacGia.AutoSize = true;
            this.lbl_tacGia.BackColor = System.Drawing.Color.White;
            this.lbl_tacGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tacGia.Location = new System.Drawing.Point(592, 73);
            this.lbl_tacGia.Name = "lbl_tacGia";
            this.lbl_tacGia.Size = new System.Drawing.Size(64, 20);
            this.lbl_tacGia.TabIndex = 26;
            this.lbl_tacGia.Text = "Tác giả";
            // 
            // lbl_nxb
            // 
            this.lbl_nxb.AutoSize = true;
            this.lbl_nxb.BackColor = System.Drawing.Color.White;
            this.lbl_nxb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nxb.Location = new System.Drawing.Point(592, 25);
            this.lbl_nxb.Name = "lbl_nxb";
            this.lbl_nxb.Size = new System.Drawing.Size(107, 20);
            this.lbl_nxb.TabIndex = 25;
            this.lbl_nxb.Text = "Nhà xuất bản";
            // 
            // lbl_tenSach
            // 
            this.lbl_tenSach.AutoSize = true;
            this.lbl_tenSach.BackColor = System.Drawing.Color.White;
            this.lbl_tenSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tenSach.ForeColor = System.Drawing.Color.Black;
            this.lbl_tenSach.Location = new System.Drawing.Point(28, 73);
            this.lbl_tenSach.Name = "lbl_tenSach";
            this.lbl_tenSach.Size = new System.Drawing.Size(78, 20);
            this.lbl_tenSach.TabIndex = 24;
            this.lbl_tenSach.Text = "Tên sách";
            // 
            // lbl_maSach
            // 
            this.lbl_maSach.AutoSize = true;
            this.lbl_maSach.BackColor = System.Drawing.Color.White;
            this.lbl_maSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_maSach.ForeColor = System.Drawing.Color.Black;
            this.lbl_maSach.Location = new System.Drawing.Point(28, 25);
            this.lbl_maSach.Name = "lbl_maSach";
            this.lbl_maSach.Size = new System.Drawing.Size(73, 20);
            this.lbl_maSach.TabIndex = 23;
            this.lbl_maSach.Text = "Mã sách";
            // 
            // Quanlysach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1301, 731);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Quanlysach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý sách";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_tacGia;
        private System.Windows.Forms.TextBox txt_nxb;
        private System.Windows.Forms.TextBox txt_tenSach;
        private System.Windows.Forms.TextBox txt_maSach;
        private System.Windows.Forms.Label lbl_tacGia;
        private System.Windows.Forms.Label lbl_nxb;
        private System.Windows.Forms.Label lbl_tenSach;
        private System.Windows.Forms.Label lbl_maSach;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
    }
}