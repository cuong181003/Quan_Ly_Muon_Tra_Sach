﻿namespace Quanlythuvien
{
    partial class Dashbroad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashbroad));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.quảnLýDanhMụcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýLoạiSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýĐộcGiảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cậpNhậtThôngTinĐộcGiảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cấpThẻĐộcGiảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýMượnTrảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýMượnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýTrảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêBáoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêLượtMượnSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêSáchBịThấtLạcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêSáchCầnThanhLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinCáNhânToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Wheat;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýDanhMụcToolStripMenuItem,
            this.quảnLýĐộcGiảToolStripMenuItem,
            this.quảnLýMượnTrảToolStripMenuItem,
            this.thốngKêBáoCáoToolStripMenuItem,
            this.thôngTinCáNhânToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1378, 58);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // quảnLýDanhMụcToolStripMenuItem
            // 
            this.quảnLýDanhMụcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýToolStripMenuItem,
            this.quảnLýLoạiSáchToolStripMenuItem});
            this.quảnLýDanhMụcToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quảnLýDanhMụcToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýDanhMụcToolStripMenuItem.Image")));
            this.quảnLýDanhMụcToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.quảnLýDanhMụcToolStripMenuItem.Name = "quảnLýDanhMụcToolStripMenuItem";
            this.quảnLýDanhMụcToolStripMenuItem.Size = new System.Drawing.Size(240, 54);
            this.quảnLýDanhMụcToolStripMenuItem.Text = "Quản Lý Danh Mục Sách";
            this.quảnLýDanhMụcToolStripMenuItem.Click += new System.EventHandler(this.quảnLýDanhMụcToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.quảnLýToolStripMenuItem.Text = "Quản lý sách";
            this.quảnLýToolStripMenuItem.Click += new System.EventHandler(this.quảnLýToolStripMenuItem_Click_1);
            // 
            // quảnLýLoạiSáchToolStripMenuItem
            // 
            this.quảnLýLoạiSáchToolStripMenuItem.Name = "quảnLýLoạiSáchToolStripMenuItem";
            this.quảnLýLoạiSáchToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.quảnLýLoạiSáchToolStripMenuItem.Text = "Quản lý thể loại sách";
            this.quảnLýLoạiSáchToolStripMenuItem.Click += new System.EventHandler(this.quảnLýLoạiSáchToolStripMenuItem_Click);
            // 
            // quảnLýĐộcGiảToolStripMenuItem
            // 
            this.quảnLýĐộcGiảToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cậpNhậtThôngTinĐộcGiảToolStripMenuItem,
            this.cấpThẻĐộcGiảToolStripMenuItem});
            this.quảnLýĐộcGiảToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quảnLýĐộcGiảToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýĐộcGiảToolStripMenuItem.Image")));
            this.quảnLýĐộcGiảToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.quảnLýĐộcGiảToolStripMenuItem.Name = "quảnLýĐộcGiảToolStripMenuItem";
            this.quảnLýĐộcGiảToolStripMenuItem.Size = new System.Drawing.Size(186, 54);
            this.quảnLýĐộcGiảToolStripMenuItem.Text = "Quản Lý Độc Giả";
            // 
            // cậpNhậtThôngTinĐộcGiảToolStripMenuItem
            // 
            this.cậpNhậtThôngTinĐộcGiảToolStripMenuItem.Name = "cậpNhậtThôngTinĐộcGiảToolStripMenuItem";
            this.cậpNhậtThôngTinĐộcGiảToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.cậpNhậtThôngTinĐộcGiảToolStripMenuItem.Text = "Cập nhật thông tin độc giả";
            this.cậpNhậtThôngTinĐộcGiảToolStripMenuItem.Click += new System.EventHandler(this.cậpNhậtThôngTinĐộcGiảToolStripMenuItem_Click);
            // 
            // cấpThẻĐộcGiảToolStripMenuItem
            // 
            this.cấpThẻĐộcGiảToolStripMenuItem.Name = "cấpThẻĐộcGiảToolStripMenuItem";
            this.cấpThẻĐộcGiảToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.cấpThẻĐộcGiảToolStripMenuItem.Text = "Quản lý thẻ";
            this.cấpThẻĐộcGiảToolStripMenuItem.Click += new System.EventHandler(this.cấpThẻĐộcGiảToolStripMenuItem_Click);
            // 
            // quảnLýMượnTrảToolStripMenuItem
            // 
            this.quảnLýMượnTrảToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýMượnToolStripMenuItem,
            this.quảnLýTrảToolStripMenuItem,
            this.quảnLýToolStripMenuItem1});
            this.quảnLýMượnTrảToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quảnLýMượnTrảToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýMượnTrảToolStripMenuItem.Image")));
            this.quảnLýMượnTrảToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.quảnLýMượnTrảToolStripMenuItem.Name = "quảnLýMượnTrảToolStripMenuItem";
            this.quảnLýMượnTrảToolStripMenuItem.Size = new System.Drawing.Size(199, 54);
            this.quảnLýMượnTrảToolStripMenuItem.Text = "Quản Lý Mượn Trả";
            // 
            // quảnLýMượnToolStripMenuItem
            // 
            this.quảnLýMượnToolStripMenuItem.Name = "quảnLýMượnToolStripMenuItem";
            this.quảnLýMượnToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.quảnLýMượnToolStripMenuItem.Text = "Mượn sách";
            this.quảnLýMượnToolStripMenuItem.Click += new System.EventHandler(this.quảnLýMượnToolStripMenuItem_Click);
            // 
            // quảnLýTrảToolStripMenuItem
            // 
            this.quảnLýTrảToolStripMenuItem.Name = "quảnLýTrảToolStripMenuItem";
            this.quảnLýTrảToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.quảnLýTrảToolStripMenuItem.Text = "Trả sách";
            this.quảnLýTrảToolStripMenuItem.Click += new System.EventHandler(this.quảnLýTrảToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem1
            // 
            this.quảnLýToolStripMenuItem1.Name = "quảnLýToolStripMenuItem1";
            this.quảnLýToolStripMenuItem1.Size = new System.Drawing.Size(243, 26);
            this.quảnLýToolStripMenuItem1.Text = "Xử lý trả sách quá hạn";
            this.quảnLýToolStripMenuItem1.Click += new System.EventHandler(this.quảnLýToolStripMenuItem1_Click);
            // 
            // thốngKêBáoCáoToolStripMenuItem
            // 
            this.thốngKêBáoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thốngKêLượtMượnSáchToolStripMenuItem,
            this.thốngKêSáchBịThấtLạcToolStripMenuItem,
            this.thốngKêSáchCầnThanhLýToolStripMenuItem,
            this.thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem});
            this.thốngKêBáoCáoToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thốngKêBáoCáoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("thốngKêBáoCáoToolStripMenuItem.Image")));
            this.thốngKêBáoCáoToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.thốngKêBáoCáoToolStripMenuItem.Name = "thốngKêBáoCáoToolStripMenuItem";
            this.thốngKêBáoCáoToolStripMenuItem.Size = new System.Drawing.Size(198, 54);
            this.thốngKêBáoCáoToolStripMenuItem.Text = "Thống Kê Báo Cáo";
            // 
            // thốngKêLượtMượnSáchToolStripMenuItem
            // 
            this.thốngKêLượtMượnSáchToolStripMenuItem.Name = "thốngKêLượtMượnSáchToolStripMenuItem";
            this.thốngKêLượtMượnSáchToolStripMenuItem.Size = new System.Drawing.Size(327, 26);
            this.thốngKêLượtMượnSáchToolStripMenuItem.Text = "Thống kê lượt mượn sách";
            this.thốngKêLượtMượnSáchToolStripMenuItem.Click += new System.EventHandler(this.thốngKêLượtMượnSáchToolStripMenuItem_Click);
            // 
            // thốngKêSáchBịThấtLạcToolStripMenuItem
            // 
            this.thốngKêSáchBịThấtLạcToolStripMenuItem.Name = "thốngKêSáchBịThấtLạcToolStripMenuItem";
            this.thốngKêSáchBịThấtLạcToolStripMenuItem.Size = new System.Drawing.Size(327, 26);
            this.thốngKêSáchBịThấtLạcToolStripMenuItem.Text = "Thống kê sách bị thất lạc";
            this.thốngKêSáchBịThấtLạcToolStripMenuItem.Click += new System.EventHandler(this.thốngKêSáchBịThấtLạcToolStripMenuItem_Click);
            // 
            // thốngKêSáchCầnThanhLýToolStripMenuItem
            // 
            this.thốngKêSáchCầnThanhLýToolStripMenuItem.Name = "thốngKêSáchCầnThanhLýToolStripMenuItem";
            this.thốngKêSáchCầnThanhLýToolStripMenuItem.Size = new System.Drawing.Size(327, 26);
            this.thốngKêSáchCầnThanhLýToolStripMenuItem.Text = "Thống kê sách cần thanh lý";
            this.thốngKêSáchCầnThanhLýToolStripMenuItem.Click += new System.EventHandler(this.thốngKêSáchCầnThanhLýToolStripMenuItem_Click);
            // 
            // thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem
            // 
            this.thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem.Name = "thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem";
            this.thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem.Size = new System.Drawing.Size(327, 26);
            this.thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem.Text = "Thống kê độc giả trả sách quá hạn";
            this.thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem.Click += new System.EventHandler(this.thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem_Click);
            // 
            // thôngTinCáNhânToolStripMenuItem
            // 
            this.thôngTinCáNhânToolStripMenuItem.Name = "thôngTinCáNhânToolStripMenuItem";
            this.thôngTinCáNhânToolStripMenuItem.Size = new System.Drawing.Size(141, 54);
            this.thôngTinCáNhânToolStripMenuItem.Text = "Thông tin cá nhân";
            this.thôngTinCáNhânToolStripMenuItem.Click += new System.EventHandler(this.thôngTinCáNhânToolStripMenuItem_Click);
            // 
            // Dashbroad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1378, 757);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Dashbroad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý mượn trả sách";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem quảnLýMượnTrảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýMượnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýTrảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem thốngKêBáoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêLượtMượnSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêSáchBịThấtLạcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêSáchCầnThanhLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêĐộcGiảTrảSáchQuáHạnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýDanhMụcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýĐộcGiảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậtThôngTinĐộcGiảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cấpThẻĐộcGiảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýLoạiSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinCáNhânToolStripMenuItem;
    }
}