﻿namespace Quanlythuvien
{
    partial class Thongtindocgia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Thongtindocgia));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox_functions = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_xoa = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_sua = new System.Windows.Forms.Button();
            this.btn_them = new System.Windows.Forms.Button();
            this.txt_diachiDG = new System.Windows.Forms.TextBox();
            this.lbl_diachiDG = new System.Windows.Forms.Label();
            this.txt_emailDG = new System.Windows.Forms.TextBox();
            this.lbl_emailDG = new System.Windows.Forms.Label();
            this.txt_sdtDG = new System.Windows.Forms.TextBox();
            this.lbl_sdtDG = new System.Windows.Forms.Label();
            this.dtp_ngaysinhDG = new System.Windows.Forms.DateTimePicker();
            this.lbl_ngaysinhDG = new System.Windows.Forms.Label();
            this.rdo_Nu = new System.Windows.Forms.RadioButton();
            this.rdo_Nam = new System.Windows.Forms.RadioButton();
            this.lbl_gioitinhDG = new System.Windows.Forms.Label();
            this.txt_hotenDG = new System.Windows.Forms.TextBox();
            this.lbl_hotenDG = new System.Windows.Forms.Label();
            this.txt_maDG = new System.Windows.Forms.TextBox();
            this.lbl_maDG = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_cccd = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox_functions.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1294, 169);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.IndianRed;
            this.label2.Location = new System.Drawing.Point(720, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "ers";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.IndianRed;
            this.label1.Location = new System.Drawing.Point(720, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Read";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(473, -20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(261, 189);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 205);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1285, 370);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(830, 226);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 31);
            this.button1.TabIndex = 7;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SeaShell;
            this.panel2.Controls.Add(this.txt_cccd);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.groupBox_functions);
            this.panel2.Controls.Add(this.txt_diachiDG);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.lbl_diachiDG);
            this.panel2.Controls.Add(this.txt_emailDG);
            this.panel2.Controls.Add(this.lbl_emailDG);
            this.panel2.Controls.Add(this.txt_sdtDG);
            this.panel2.Controls.Add(this.lbl_sdtDG);
            this.panel2.Controls.Add(this.dtp_ngaysinhDG);
            this.panel2.Controls.Add(this.lbl_ngaysinhDG);
            this.panel2.Controls.Add(this.rdo_Nu);
            this.panel2.Controls.Add(this.rdo_Nam);
            this.panel2.Controls.Add(this.lbl_gioitinhDG);
            this.panel2.Controls.Add(this.txt_hotenDG);
            this.panel2.Controls.Add(this.lbl_hotenDG);
            this.panel2.Controls.Add(this.txt_maDG);
            this.panel2.Controls.Add(this.lbl_maDG);
            this.panel2.Location = new System.Drawing.Point(12, 605);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1277, 269);
            this.panel2.TabIndex = 9;
            // 
            // groupBox_functions
            // 
            this.groupBox_functions.BackColor = System.Drawing.Color.SeaShell;
            this.groupBox_functions.Controls.Add(this.button3);
            this.groupBox_functions.Controls.Add(this.btn_xoa);
            this.groupBox_functions.Controls.Add(this.button2);
            this.groupBox_functions.Controls.Add(this.btn_sua);
            this.groupBox_functions.Controls.Add(this.btn_them);
            this.groupBox_functions.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_functions.Location = new System.Drawing.Point(968, 147);
            this.groupBox_functions.Name = "groupBox_functions";
            this.groupBox_functions.Size = new System.Drawing.Size(290, 110);
            this.groupBox_functions.TabIndex = 52;
            this.groupBox_functions.TabStop = false;
            this.groupBox_functions.Text = "Chức năng";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button3.Location = new System.Drawing.Point(176, 66);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(108, 35);
            this.button3.TabIndex = 53;
            this.button3.Text = "Kiểm tra";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_xoa
            // 
            this.btn_xoa.BackColor = System.Drawing.Color.Firebrick;
            this.btn_xoa.Location = new System.Drawing.Point(203, 27);
            this.btn_xoa.Name = "btn_xoa";
            this.btn_xoa.Size = new System.Drawing.Size(81, 35);
            this.btn_xoa.TabIndex = 4;
            this.btn_xoa.Text = "Xóa";
            this.btn_xoa.UseVisualStyleBackColor = false;
            this.btn_xoa.Click += new System.EventHandler(this.btn_xoa_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MintCream;
            this.button2.Location = new System.Drawing.Point(6, 66);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 38);
            this.button2.TabIndex = 43;
            this.button2.Text = "Tìm kiếm";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_sua
            // 
            this.btn_sua.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_sua.Location = new System.Drawing.Point(107, 27);
            this.btn_sua.Name = "btn_sua";
            this.btn_sua.Size = new System.Drawing.Size(81, 35);
            this.btn_sua.TabIndex = 3;
            this.btn_sua.Text = "Sửa";
            this.btn_sua.UseVisualStyleBackColor = false;
            this.btn_sua.Click += new System.EventHandler(this.btn_sua_Click);
            // 
            // btn_them
            // 
            this.btn_them.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_them.Location = new System.Drawing.Point(6, 26);
            this.btn_them.Name = "btn_them";
            this.btn_them.Size = new System.Drawing.Size(81, 35);
            this.btn_them.TabIndex = 1;
            this.btn_them.Text = "Thêm";
            this.btn_them.UseVisualStyleBackColor = false;
            this.btn_them.Click += new System.EventHandler(this.btn_them_Click);
            // 
            // txt_diachiDG
            // 
            this.txt_diachiDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_diachiDG.Location = new System.Drawing.Point(158, 174);
            this.txt_diachiDG.Name = "txt_diachiDG";
            this.txt_diachiDG.Size = new System.Drawing.Size(296, 27);
            this.txt_diachiDG.TabIndex = 27;
            // 
            // lbl_diachiDG
            // 
            this.lbl_diachiDG.AutoSize = true;
            this.lbl_diachiDG.BackColor = System.Drawing.Color.White;
            this.lbl_diachiDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_diachiDG.Location = new System.Drawing.Point(27, 177);
            this.lbl_diachiDG.Name = "lbl_diachiDG";
            this.lbl_diachiDG.Size = new System.Drawing.Size(61, 20);
            this.lbl_diachiDG.TabIndex = 26;
            this.lbl_diachiDG.Text = "Địa chỉ";
            // 
            // txt_emailDG
            // 
            this.txt_emailDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_emailDG.Location = new System.Drawing.Point(158, 125);
            this.txt_emailDG.Name = "txt_emailDG";
            this.txt_emailDG.Size = new System.Drawing.Size(374, 27);
            this.txt_emailDG.TabIndex = 25;
            // 
            // lbl_emailDG
            // 
            this.lbl_emailDG.AutoSize = true;
            this.lbl_emailDG.BackColor = System.Drawing.Color.White;
            this.lbl_emailDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emailDG.Location = new System.Drawing.Point(27, 128);
            this.lbl_emailDG.Name = "lbl_emailDG";
            this.lbl_emailDG.Size = new System.Drawing.Size(51, 20);
            this.lbl_emailDG.TabIndex = 24;
            this.lbl_emailDG.Text = "Email";
            // 
            // txt_sdtDG
            // 
            this.txt_sdtDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sdtDG.Location = new System.Drawing.Point(158, 224);
            this.txt_sdtDG.Name = "txt_sdtDG";
            this.txt_sdtDG.Size = new System.Drawing.Size(152, 27);
            this.txt_sdtDG.TabIndex = 23;
            // 
            // lbl_sdtDG
            // 
            this.lbl_sdtDG.AutoSize = true;
            this.lbl_sdtDG.BackColor = System.Drawing.Color.White;
            this.lbl_sdtDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sdtDG.Location = new System.Drawing.Point(27, 231);
            this.lbl_sdtDG.Name = "lbl_sdtDG";
            this.lbl_sdtDG.Size = new System.Drawing.Size(106, 20);
            this.lbl_sdtDG.TabIndex = 22;
            this.lbl_sdtDG.Text = "Số điện thoại";
            // 
            // dtp_ngaysinhDG
            // 
            this.dtp_ngaysinhDG.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_ngaysinhDG.CustomFormat = "";
            this.dtp_ngaysinhDG.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_ngaysinhDG.Location = new System.Drawing.Point(1058, 77);
            this.dtp_ngaysinhDG.Name = "dtp_ngaysinhDG";
            this.dtp_ngaysinhDG.Size = new System.Drawing.Size(150, 22);
            this.dtp_ngaysinhDG.TabIndex = 21;
            // 
            // lbl_ngaysinhDG
            // 
            this.lbl_ngaysinhDG.AutoSize = true;
            this.lbl_ngaysinhDG.BackColor = System.Drawing.Color.White;
            this.lbl_ngaysinhDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ngaysinhDG.ForeColor = System.Drawing.Color.Black;
            this.lbl_ngaysinhDG.Location = new System.Drawing.Point(929, 77);
            this.lbl_ngaysinhDG.Name = "lbl_ngaysinhDG";
            this.lbl_ngaysinhDG.Size = new System.Drawing.Size(83, 20);
            this.lbl_ngaysinhDG.TabIndex = 20;
            this.lbl_ngaysinhDG.Text = "Ngày sinh";
            // 
            // rdo_Nu
            // 
            this.rdo_Nu.AutoSize = true;
            this.rdo_Nu.BackColor = System.Drawing.Color.White;
            this.rdo_Nu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_Nu.Location = new System.Drawing.Point(1157, 30);
            this.rdo_Nu.Name = "rdo_Nu";
            this.rdo_Nu.Size = new System.Drawing.Size(51, 24);
            this.rdo_Nu.TabIndex = 19;
            this.rdo_Nu.Text = "Nữ";
            this.rdo_Nu.UseVisualStyleBackColor = false;
            // 
            // rdo_Nam
            // 
            this.rdo_Nam.AutoSize = true;
            this.rdo_Nam.BackColor = System.Drawing.Color.White;
            this.rdo_Nam.Checked = true;
            this.rdo_Nam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdo_Nam.Location = new System.Drawing.Point(1058, 30);
            this.rdo_Nam.Name = "rdo_Nam";
            this.rdo_Nam.Size = new System.Drawing.Size(65, 24);
            this.rdo_Nam.TabIndex = 18;
            this.rdo_Nam.TabStop = true;
            this.rdo_Nam.Text = "Nam";
            this.rdo_Nam.UseVisualStyleBackColor = false;
            // 
            // lbl_gioitinhDG
            // 
            this.lbl_gioitinhDG.AutoSize = true;
            this.lbl_gioitinhDG.BackColor = System.Drawing.Color.White;
            this.lbl_gioitinhDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gioitinhDG.ForeColor = System.Drawing.Color.Black;
            this.lbl_gioitinhDG.Location = new System.Drawing.Point(929, 34);
            this.lbl_gioitinhDG.Name = "lbl_gioitinhDG";
            this.lbl_gioitinhDG.Size = new System.Drawing.Size(71, 20);
            this.lbl_gioitinhDG.TabIndex = 17;
            this.lbl_gioitinhDG.Text = "Giới tính";
            // 
            // txt_hotenDG
            // 
            this.txt_hotenDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_hotenDG.Location = new System.Drawing.Point(156, 72);
            this.txt_hotenDG.Name = "txt_hotenDG";
            this.txt_hotenDG.Size = new System.Drawing.Size(253, 27);
            this.txt_hotenDG.TabIndex = 16;
            // 
            // lbl_hotenDG
            // 
            this.lbl_hotenDG.AutoSize = true;
            this.lbl_hotenDG.BackColor = System.Drawing.Color.White;
            this.lbl_hotenDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hotenDG.ForeColor = System.Drawing.Color.Black;
            this.lbl_hotenDG.Location = new System.Drawing.Point(27, 75);
            this.lbl_hotenDG.Name = "lbl_hotenDG";
            this.lbl_hotenDG.Size = new System.Drawing.Size(59, 20);
            this.lbl_hotenDG.TabIndex = 15;
            this.lbl_hotenDG.Text = "Họ tên";
            // 
            // txt_maDG
            // 
            this.txt_maDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maDG.Location = new System.Drawing.Point(156, 27);
            this.txt_maDG.Name = "txt_maDG";
            this.txt_maDG.Size = new System.Drawing.Size(167, 27);
            this.txt_maDG.TabIndex = 14;
            // 
            // lbl_maDG
            // 
            this.lbl_maDG.AutoSize = true;
            this.lbl_maDG.BackColor = System.Drawing.Color.White;
            this.lbl_maDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_maDG.ForeColor = System.Drawing.Color.Black;
            this.lbl_maDG.Location = new System.Drawing.Point(27, 30);
            this.lbl_maDG.Name = "lbl_maDG";
            this.lbl_maDG.Size = new System.Drawing.Size(91, 20);
            this.lbl_maDG.TabIndex = 13;
            this.lbl_maDG.Text = "Mã độc giả";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(495, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 20);
            this.label3.TabIndex = 53;
            this.label3.Text = "cccd";
            // 
            // txt_cccd
            // 
            this.txt_cccd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cccd.Location = new System.Drawing.Point(564, 23);
            this.txt_cccd.Name = "txt_cccd";
            this.txt_cccd.Size = new System.Drawing.Size(212, 27);
            this.txt_cccd.TabIndex = 54;
            // 
            // Thongtindocgia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1301, 700);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Thongtindocgia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý độc giả";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox_functions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_diachiDG;
        private System.Windows.Forms.Label lbl_diachiDG;
        private System.Windows.Forms.TextBox txt_emailDG;
        private System.Windows.Forms.Label lbl_emailDG;
        private System.Windows.Forms.TextBox txt_sdtDG;
        private System.Windows.Forms.Label lbl_sdtDG;
        private System.Windows.Forms.DateTimePicker dtp_ngaysinhDG;
        private System.Windows.Forms.Label lbl_ngaysinhDG;
        private System.Windows.Forms.RadioButton rdo_Nu;
        private System.Windows.Forms.RadioButton rdo_Nam;
        private System.Windows.Forms.Label lbl_gioitinhDG;
        private System.Windows.Forms.TextBox txt_hotenDG;
        private System.Windows.Forms.Label lbl_hotenDG;
        private System.Windows.Forms.TextBox txt_maDG;
        private System.Windows.Forms.Label lbl_maDG;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox_functions;
        private System.Windows.Forms.Button btn_xoa;
        private System.Windows.Forms.Button btn_sua;
        private System.Windows.Forms.Button btn_them;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txt_cccd;
        private System.Windows.Forms.Label label3;
    }
}